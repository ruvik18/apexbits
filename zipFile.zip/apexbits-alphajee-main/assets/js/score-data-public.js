(function () {
  'use strict';

  const SCORE_CHART_MIN_START = 120;
  const SCORE_CHART_MAX_START = 320;
  const SCORE_BUCKET_SIZE = 10;
  const SCORE_MAX = 390;
  const DATA_VERSION = 'bucketed-score-data-20260618-1';
  const DEFAULT_DATASET = 'phodu';

  const DATASETS = {
    phodu: {
      label: 'Phodu Club Data',
      eyebrow: 'Phodu Club bucketed score data',
      heading: 'Phodu Club Data Distribution',
      copy: 'Scores are stored as 10-mark buckets, not exact submitted marks.',
      path: 'assets/data/phodu-scores.json',
      loading: 'Loading Phodu Club score buckets...',
      unavailable: 'Phodu Club Data could not be loaded. Check that assets/data/phodu-scores.json is included in the deployed site.'
    },
    apexbits: {
      label: 'ApexBITS Data',
      eyebrow: 'ApexBITS bucketed score data',
      heading: 'ApexBITS Data Distribution',
      copy: 'Counts are loaded as 10-mark buckets. Exact submitted scores are not shipped on this page.',
      path: 'assets/data/scores.json',
      loading: 'Loading ApexBITS score buckets...',
      unavailable: 'ApexBITS Data could not be loaded. Check that assets/data/scores.json is included in the deployed site.'
    }
  };

  const els = {
    scoreSourceTabs: document.getElementById('scoreSourceTabs'),
    scoreDatasetEyebrow: document.getElementById('scoreDatasetEyebrow'),
    scoreDatasetHeading: document.getElementById('scoreDatasetHeading'),
    scoreDatasetCopy: document.getElementById('scoreDatasetCopy'),
    scoreMetricGrid: document.getElementById('scoreMetricGrid'),
    scoreDataStatus: document.getElementById('scoreDataStatus'),
    scoreChart: document.getElementById('scoreChart'),
    scoreDataUpdated: document.getElementById('scoreDataUpdated'),
    scoreCompareInput: document.getElementById('scoreCompareInput'),
    scoreCompareSlider: document.getElementById('scoreCompareSlider'),
    scoreHigherCount: document.getElementById('scoreHigherCount'),
    scorePercentile: document.getElementById('scorePercentile'),
    scoreHigherDataset: document.getElementById('scoreHigherDataset'),
    scoreHigherText: document.getElementById('scoreHigherText')
  };

  let activeDataset = DEFAULT_DATASET;
  let activeScoreData = null;
  let latestRequestId = 0;
  const dataCache = new Map();

  function escapeHtml(value) {
    return String(value).replace(/[&<>"']/g, ch => ({
      '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
    }[ch]));
  }

  function formatNumber(value) {
    return new Intl.NumberFormat('en-IN').format(Number(value) || 0);
  }

  function formatScoreStat(value) {
    const number = Number(value);
    if (!Number.isFinite(number)) return '0';
    const rounded = Math.round(number * 10) / 10;
    return new Intl.NumberFormat('en-IN', {
      maximumFractionDigits: Number.isInteger(rounded) ? 0 : 1
    }).format(rounded);
  }

  function formatPercentNumber(value) {
    const number = Number(value);
    if (!Number.isFinite(number)) return null;
    const clipped = Math.max(0, Math.min(100, number));
    return new Intl.NumberFormat('en-IN', {
      minimumFractionDigits: 1,
      maximumFractionDigits: 1
    }).format(clipped);
  }

  function formatPercentileRange(range) {
    if (!range) return '-- %ile';
    const min = formatPercentNumber(range.min);
    const max = formatPercentNumber(range.max);
    if (min === null || max === null) return '-- %ile';
    return min === max ? `${min}%ile` : `${min}-${max}%ile`;
  }

  function formatRange(range, formatter = formatNumber) {
    if (!range) return formatter(0);
    const min = Math.max(0, Math.round(Number(range.min) || 0));
    const max = Math.max(0, Math.round(Number(range.max) || 0));
    return min === max ? formatter(min) : `${formatter(min)}-${formatter(max)}`;
  }

  function metricCard(label, value, formatter = formatNumber) {
    const rendered = typeof value === 'string' ? value : formatter(value);
    return `<div class="metric-card"><span>${escapeHtml(label)}</span><strong>${escapeHtml(rendered)}</strong></div>`;
  }

  function getDatasetConfig(datasetKey) {
    return DATASETS[datasetKey] || DATASETS[DEFAULT_DATASET];
  }

  function getDatasetUrl(config) {
    return `${config.path}?v=${DATA_VERSION}`;
  }

  function showStatus(message) {
    if (!els.scoreDataStatus) return;
    els.scoreDataStatus.hidden = false;
    els.scoreDataStatus.textContent = message;
  }

  function hideStatus() {
    if (!els.scoreDataStatus) return;
    els.scoreDataStatus.hidden = true;
    els.scoreDataStatus.textContent = '';
  }

  function renderDatasetChrome(config) {
    if (els.scoreDatasetEyebrow) els.scoreDatasetEyebrow.textContent = config.eyebrow;
    if (els.scoreDatasetHeading) els.scoreDatasetHeading.textContent = config.heading;
    if (els.scoreDatasetCopy) els.scoreDatasetCopy.textContent = config.copy;
  }

  function setActiveDataset(datasetKey) {
    activeDataset = DATASETS[datasetKey] ? datasetKey : DEFAULT_DATASET;

    if (!els.scoreSourceTabs) return;
    const tabs = Array.from(els.scoreSourceTabs.querySelectorAll('[data-dataset]'));
    for (const tab of tabs) {
      const isActive = tab.dataset.dataset === activeDataset;
      tab.classList.toggle('active', isActive);
      tab.setAttribute('aria-selected', isActive ? 'true' : 'false');
    }
  }

  async function fetchScoreData(datasetKey) {
    const config = getDatasetConfig(datasetKey);
    if (dataCache.has(datasetKey)) return dataCache.get(datasetKey);

    let data = null;

    try {
      const response = await fetch(getDatasetUrl(config), { method: 'GET', cache: 'default' });
      const fetched = await response.json().catch(() => null);
      if (response.ok) data = normalizeScorePayload(fetched);
    } catch (_) {
      data = null;
    }

    if (!data) throw new Error('SCORE_ANALYSIS_FAILED');
    dataCache.set(datasetKey, data);
    return data;
  }

  function normalizeScorePayload(payload) {
    if (!payload || typeof payload !== 'object') return null;

    if (Array.isArray(payload.buckets)) {
      return buildBucketData(payload);
    }

    // Backward compatibility for old local files only. The shipped data files no
    // longer contain exact score arrays.
    if (Array.isArray(payload.scores)) {
      return buildBucketData(bucketExactScores(payload.scores));
    }

    return null;
  }

  function bucketExactScores(rawScores) {
    const counts = new Map();
    let totalEntries = 0;

    for (const rawScore of rawScores) {
      const score = Number(rawScore);
      if (!Number.isInteger(score) || score < 0 || score > SCORE_MAX) continue;
      const start = Math.floor(score / SCORE_BUCKET_SIZE) * SCORE_BUCKET_SIZE;
      counts.set(start, (counts.get(start) || 0) + 1);
      totalEntries += 1;
    }

    return {
      bucketSize: SCORE_BUCKET_SIZE,
      scoreMax: SCORE_MAX,
      totalEntries,
      buckets: Array.from(counts.entries()).map(([start, count]) => ({
        start,
        end: Math.min(start + SCORE_BUCKET_SIZE - 1, SCORE_MAX),
        count
      }))
    };
  }

  function buildBucketData(payload) {
    const bucketSize = Math.max(1, Math.round(Number(payload.bucketSize) || SCORE_BUCKET_SIZE));
    const scoreMax = Math.max(bucketSize, Math.round(Number(payload.scoreMax) || SCORE_MAX));
    const buckets = normalizeAllBuckets(payload.buckets, bucketSize, scoreMax);
    const countedEntries = buckets.reduce((sum, bucket) => sum + bucket.count, 0);
    const totalEntries = Math.max(0, Math.round(Number(payload.totalEntries) || countedEntries));

    addCumulativeCounts(buckets);

    return {
      ok: true,
      totalEntries,
      bucketSize,
      scoreMax,
      meanScore: estimateMeanScore(buckets, totalEntries),
      medianRange: findMedianRange(buckets, totalEntries),
      buckets,
      chartBuckets: buckets.filter(bucket => bucket.start >= SCORE_CHART_MIN_START && bucket.start <= SCORE_CHART_MAX_START)
    };
  }

  function normalizeAllBuckets(rawBuckets, bucketSize, scoreMax) {
    const counts = new Map();

    for (const bucket of Array.isArray(rawBuckets) ? rawBuckets : []) {
      const start = Math.floor((Number(bucket.start) || 0) / bucketSize) * bucketSize;
      const count = Math.max(0, Math.round(Number(bucket.count) || 0));
      if (start < 0 || start > scoreMax || count <= 0) continue;
      counts.set(start, (counts.get(start) || 0) + count);
    }

    const buckets = [];
    for (let start = 0; start <= scoreMax; start += bucketSize) {
      buckets.push({
        start,
        end: Math.min(start + bucketSize - 1, scoreMax),
        count: counts.get(start) || 0,
        cumulative: 0
      });
    }

    return buckets;
  }

  function addCumulativeCounts(buckets) {
    let cumulative = 0;
    for (let index = buckets.length - 1; index >= 0; index -= 1) {
      cumulative += buckets[index].count;
      buckets[index].cumulative = cumulative;
    }
  }

  function estimateMeanScore(buckets, totalEntries) {
    if (!totalEntries) return 0;
    const weighted = buckets.reduce((sum, bucket) => {
      const midpoint = (bucket.start + bucket.end) / 2;
      return sum + midpoint * bucket.count;
    }, 0);
    return weighted / totalEntries;
  }

  function findMedianRange(buckets, totalEntries) {
    if (!totalEntries) return '--';
    const target = (totalEntries + 1) / 2;
    let cumulative = 0;
    for (const bucket of buckets) {
      cumulative += bucket.count;
      if (cumulative >= target) return formatBucketRange(bucket);
    }
    return '--';
  }

  function getCurrentInputScore() {
    if (!els.scoreCompareInput) return null;
    const raw = String(els.scoreCompareInput.value || '').trim();
    if (raw === '') return null;
    const score = Number(raw);
    if (!Number.isFinite(score)) return null;
    return Math.max(0, Math.min(SCORE_MAX, Math.round(score)));
  }

  function setComparisonControls(score) {
    const value = score === null ? '' : String(score);
    if (els.scoreCompareInput && els.scoreCompareInput.value !== value) {
      els.scoreCompareInput.value = value;
    }
    if (els.scoreCompareSlider && score !== null && els.scoreCompareSlider.value !== String(score)) {
      els.scoreCompareSlider.value = String(score);
    }
  }

  function findBucketForScore(data, score) {
    const bucketSize = data && data.bucketSize ? data.bucketSize : SCORE_BUCKET_SIZE;
    const scoreMax = data && data.scoreMax ? data.scoreMax : SCORE_MAX;
    const start = Math.min(Math.floor(score / bucketSize) * bucketSize, scoreMax);
    const end = Math.min(start + bucketSize - 1, scoreMax);
    return { start, end };
  }

  function formatBucketRange(bucket) {
    if (!bucket) return '--';
    return bucket.start === bucket.end ? String(bucket.start) : `${bucket.start}-${bucket.end}`;
  }

  function estimateHigherRange(data, score) {
    if (!data || !Array.isArray(data.buckets) || score === null) {
      return { min: 0, max: 0 };
    }

    let minimum = 0;
    let maximum = 0;
    for (const bucket of data.buckets) {
      const count = Number(bucket.count) || 0;
      if (bucket.start > score) minimum += count;
      if (bucket.end > score) maximum += count;
    }

    return { min: minimum, max: maximum };
  }

  function renderScoreComparison(data, config) {
    const score = getCurrentInputScore();
    setComparisonControls(score);

    const totalEntries = data && Number(data.totalEntries) ? Number(data.totalEntries) : 0;
    if (els.scoreHigherDataset) {
      els.scoreHigherDataset.textContent = `${config.label} · ${formatNumber(totalEntries)} bucketed entries`;
    }

    if (!data || !Array.isArray(data.buckets) || score === null) {
      if (els.scoreHigherCount) els.scoreHigherCount.textContent = '--';
      if (els.scorePercentile) els.scorePercentile.textContent = '-- %ile';
      if (els.scoreHigherText) els.scoreHigherText.textContent = 'Enter your score to compare it with the selected bucketed data source.';
      return;
    }

    const higherRange = estimateHigherRange(data, score);
    const lowerOrEqualRange = {
      min: Math.max(0, totalEntries - higherRange.max),
      max: Math.max(0, totalEntries - higherRange.min)
    };
    const percentileRange = totalEntries > 0 ? {
      min: (lowerOrEqualRange.min / totalEntries) * 100,
      max: (lowerOrEqualRange.max / totalEntries) * 100
    } : null;
    const inputBucket = findBucketForScore(data, score);

    if (els.scoreHigherCount) els.scoreHigherCount.textContent = formatRange(higherRange);
    if (els.scorePercentile) els.scorePercentile.textContent = formatPercentileRange(percentileRange);
    if (els.scoreHigherText) {
      els.scoreHigherText.textContent = `Exact marks are hidden in ${data.bucketSize}-mark buckets. ${formatRange(higherRange)} of ${formatNumber(totalEntries)} entries may be above a score in the ${formatBucketRange(inputBucket)} bucket. Percentile estimate: ${formatPercentileRange(percentileRange)}.`;
    }
  }

  function setupScoreComparison() {
    if (!els.scoreCompareInput && !els.scoreCompareSlider) return;

    if (els.scoreCompareInput) {
      els.scoreCompareInput.addEventListener('input', () => {
        const score = getCurrentInputScore();
        if (score !== null) setComparisonControls(score);
        renderScoreComparison(activeScoreData, getDatasetConfig(activeDataset));
      });

      els.scoreCompareInput.addEventListener('blur', () => {
        const score = getCurrentInputScore();
        if (score !== null) setComparisonControls(score);
        renderScoreComparison(activeScoreData, getDatasetConfig(activeDataset));
      });
    }

    if (els.scoreCompareSlider) {
      els.scoreCompareSlider.addEventListener('input', () => {
        const score = Math.max(0, Math.min(SCORE_MAX, Math.round(Number(els.scoreCompareSlider.value) || 0)));
        setComparisonControls(score);
        renderScoreComparison(activeScoreData, getDatasetConfig(activeDataset));
      });
    }
  }

  function renderScoreData(data, config) {
    activeScoreData = data;
    hideStatus();
    renderDatasetChrome(config);

    const totalEntries = Number(data.totalEntries) || 0;
    const above300Range = estimateHigherRange(data, 300);
    const above270Range = estimateHigherRange(data, 270);
    const meanScore = Number(data.meanScore) || 0;

    if (els.scoreMetricGrid) {
      els.scoreMetricGrid.innerHTML = [
        metricCard('Above 300 est.', formatRange(above300Range)),
        metricCard('Above 270 est.', formatRange(above270Range)),
        metricCard('Mean est.', `~ ${formatScoreStat(meanScore)}`),
        metricCard('Median bucket', data.medianRange || '--')
      ].join('');
    }

    if (els.scoreDataUpdated) {
      els.scoreDataUpdated.textContent = `${config.label} · ${formatNumber(totalEntries)} bucketed entries`;
    }

    renderScoreComparison(data, config);

    if (!els.scoreChart) return;

    const buckets = Array.isArray(data.chartBuckets) ? data.chartBuckets : [];
    const maxCount = Math.max(1, ...buckets.map(bucket => Number(bucket.count) || 0));
    els.scoreChart.style.setProperty('--bar-count', String(buckets.length || 1));

    els.scoreChart.innerHTML = buckets.map((bucket, index) => {
      const count = Number(bucket.count) || 0;
      const cumulative = Number(bucket.cumulative) || 0;
      const height = Math.max(count > 0 ? 3 : 0, Math.round((count / maxCount) * 100));
      const range = formatBucketRange(bucket);
      const label = index % 2 === 0 ? String(bucket.start) : '';
      return `
        <div class="score-bar-item">
          <div class="score-bar" style="height:${height}%" tabindex="0" aria-label="Score bucket ${escapeHtml(range)}, ${count} entries, cumulative ${cumulative}">
            <span class="score-tooltip">
              <strong>Score Bucket: ${escapeHtml(range)}</strong>
              <span>Entries in Bucket: ${escapeHtml(formatNumber(count))}</span>
              <span>Cumulative (This &amp; Above): ${escapeHtml(formatNumber(cumulative))}</span>
            </span>
          </div>
          <span class="bar-label">${escapeHtml(label)}</span>
        </div>
      `;
    }).join('');
  }

  function setLoadingState(config) {
    activeScoreData = null;
    renderDatasetChrome(config);
    if (els.scoreMetricGrid) els.scoreMetricGrid.innerHTML = '';
    if (els.scoreDataUpdated) els.scoreDataUpdated.textContent = 'Loading...';
    if (els.scoreHigherCount) els.scoreHigherCount.textContent = '--';
    if (els.scorePercentile) els.scorePercentile.textContent = '-- %ile';
    if (els.scoreHigherDataset) els.scoreHigherDataset.textContent = `${config.label} · loading...`;
    if (els.scoreHigherText) els.scoreHigherText.textContent = 'Loading the selected bucketed dataset...';
    if (els.scoreChart) {
      els.scoreChart.style.setProperty('--bar-count', '1');
      els.scoreChart.innerHTML = `<div class="load-card">${escapeHtml(config.loading)}</div>`;
    }
    hideStatus();
  }

  async function start(datasetKey) {
    const nextDataset = DATASETS[datasetKey] ? datasetKey : activeDataset;
    const config = getDatasetConfig(nextDataset);
    const requestId = latestRequestId + 1;
    latestRequestId = requestId;

    setActiveDataset(nextDataset);
    setLoadingState(config);

    try {
      const data = await fetchScoreData(nextDataset);
      if (requestId !== latestRequestId) return;
      renderScoreData(data, config);
    } catch (err) {
      if (requestId !== latestRequestId) return;
      activeScoreData = null;
      showStatus(config.unavailable);
      if (els.scoreDataUpdated) els.scoreDataUpdated.textContent = 'Unavailable';
      if (els.scoreHigherCount) els.scoreHigherCount.textContent = '--';
      if (els.scorePercentile) els.scorePercentile.textContent = '-- %ile';
      if (els.scoreHigherDataset) els.scoreHigherDataset.textContent = `${config.label} · unavailable`;
      if (els.scoreHigherText) els.scoreHigherText.textContent = 'The selected bucketed dataset could not be loaded.';
      if (els.scoreChart) els.scoreChart.innerHTML = '';
    }
  }

  function setupSourceTabs() {
    if (!els.scoreSourceTabs) return;
    const tabs = Array.from(els.scoreSourceTabs.querySelectorAll('[data-dataset]'));

    tabs.forEach((tab, index) => {
      tab.addEventListener('click', () => start(tab.dataset.dataset));
      tab.addEventListener('keydown', event => {
        if (event.key !== 'ArrowLeft' && event.key !== 'ArrowRight') return;
        event.preventDefault();
        const direction = event.key === 'ArrowRight' ? 1 : -1;
        const nextIndex = (index + direction + tabs.length) % tabs.length;
        tabs[nextIndex].focus();
        start(tabs[nextIndex].dataset.dataset);
      });
    });
  }

  function init() {
    setupSourceTabs();
    setupScoreComparison();
    start(DEFAULT_DATASET);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init, { once: true });
  } else {
    init();
  }
}());
