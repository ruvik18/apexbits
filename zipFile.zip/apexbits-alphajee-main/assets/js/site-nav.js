(function () {
  function ready(fn) {
    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', fn, { once: true });
    } else {
      fn();
    }
  }

  ready(function () {
    const toggle = document.querySelector('.menu-toggle');
    const scrim = document.querySelector('.nav-scrim');

    function setOpen(open) {
      const shouldOpen = Boolean(open);
      document.body.classList.toggle('nav-open', shouldOpen);
      if (toggle) toggle.setAttribute('aria-expanded', shouldOpen ? 'true' : 'false');
    }

    if (toggle) {
      toggle.addEventListener('click', function () {
        setOpen(!document.body.classList.contains('nav-open'));
      });
    }

    if (scrim) {
      scrim.addEventListener('click', function () { setOpen(false); });
    }

    function isLocalPreview() {
      const host = window.location.hostname;
      return window.location.protocol === 'file:' || host === 'localhost' || host === '127.0.0.1' || host === '0.0.0.0';
    }

    if (isLocalPreview()) {
      document.querySelectorAll('a[href="predictor"], a[href="score-data"]').forEach(function (anchor) {
        anchor.setAttribute('href', anchor.getAttribute('href') + '.html');
      });
    }

    document.querySelectorAll('.nav-links a').forEach(function (link) {
      link.addEventListener('click', function () { setOpen(false); });
    });

    document.addEventListener('keydown', function (event) {
      if (event.key === 'Escape') setOpen(false);
    });

    window.addEventListener('pageshow', function () { setOpen(false); });
    window.addEventListener('pagehide', function () { setOpen(false); });
  });
}());
